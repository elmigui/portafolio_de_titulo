from rest_framework import serializers
from django.contrib.auth.models import User
from .models import *
from datetime import datetime



#### USUARIO ####  
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'password']

class EmpleadoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Empleado
        fields = ['id_empleado', 'rut', 'dv', 'p_nombre', 's_nombre', 'p_apellido', 's_apellido']

class CuentaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cuenta
        fields = ['id_cuenta', 'empleado', 'usuario', 'contrasena', 'correo', 'tipo_cuenta', 'estado']



#### REPRESENTANTE Y MUNICIPALIDAD #### 
class RepresentanteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Representante
        fields = ['id_representante', 'p_nombre', 's_nombre', 'p_apellido', 's_apellido', 'email', 'telefono']

class MunicipalidadSerializer(serializers.ModelSerializer):
    #representante = RepresentanteSerializer()
    class Meta:
        model = Municipalidad
        fields = ['id_municipalidad', 'comuna', 'representante']


#### CRUCES E INVENTARIOS #### 
class InventarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Inventario
        fields = ['id_inventario', 'controlador', 'sensor', 'botoneras', 'poste1', 'poste2', 'poste3', 'poste4']

class CruceSerializer(serializers.ModelSerializer):
    municipalidad = MunicipalidadSerializer()
    #inventario = InventarioSerializer()
    class Meta:
        model = Cruce
        fields = ['id_cruce', 'calle1', 'calle2', 'municipalidad', 'inventario']


#### SISTEMA SOLICITUDES ####
class EstadoSolicitudSerializer(serializers.ModelSerializer):
    class Meta:
        model = EstadoSolicitud
        fields = ['id_e_solicitud', 'clasificacion', 'descripcion']

class SolicitudSerializer(serializers.ModelSerializer):
    formatted_hora = serializers.SerializerMethodField()
    #cruce = CruceSerializer()
    #estado = EstadoSolicitudSerializer()
    class Meta:
        model = Solicitud
        fields = ['id_solicitud', 'fecha', 'formatted_hora', 'descripcion', 'cruce', 'estado']

    def get_formatted_hora(self, obj):
        return obj.hora.strftime('%H:%M')


#### SISTEMA REPORTES ####
class ReporteSerializer(serializers.ModelSerializer):
    formatted_hora = serializers.SerializerMethodField()
    #cruce = CruceSerializer()
    #cuenta = CuentaSerializer()
    class Meta:
        model = Reporte
        fields = ['id_reporte', 'cruce', 'cuenta', 'formatted_hora', 'fecha',  'r_botonera', 'r_controlador', 'r_sensor', 'r_poste1', 'r_poste2', 'r_poste3', 'r_poste4']

    def get_formatted_hora(self, obj):
        return obj.hora.strftime('%H:%M')


#### SISTEMA INFORMES ####
class InformeSerializer(serializers.ModelSerializer):
    #reporte = ReporteSerializer()
    class Meta:
        model = Informe
        fields = ['id_informe', 'mensaje', 'reporte']







