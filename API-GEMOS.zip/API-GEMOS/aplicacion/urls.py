from django.urls import path, include
from rest_framework import routers
from aplicacion import views

router = routers.DefaultRouter()

router.register(r'emplear', views.EmpleadoViewSet)
router.register(r'cuentiar', views.CuentaViewSet)
router.register(r'representar', views.RepresentanteViewSet)
router.register(r'municipar', views.MunicipalidadViewSet)
router.register(r'inventar', views.InventarioViewSet)
router.register(r'cruces', views.CruceViewSet)
router.register(r'estatar', views.EstadoSolicitudViewSet)
router.register(r'solicitar', views.SolicitudViewSet)
router.register(r'reportar', views.ReporteViewSet)
router.register(r'informar', views.InformeViewSet)


urlpatterns = [
    path('', include(router.urls))
]