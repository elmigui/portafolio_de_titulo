from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User

# Funciones para obtener fecha y hora actuales
def get_current_time():
    return timezone.localtime().time()

def get_current_date():
    return timezone.localdate()


# Modelo de Usuario
class Empleado(models.Model):
    id_empleado = models.AutoField(primary_key=True)
    rut = models.IntegerField(null=False) 
    dv = models.CharField(max_length=1, null=False) 
    p_nombre = models.CharField(max_length=15, null=False)
    s_nombre = models.CharField(max_length=15, null=True, blank=True)
    p_apellido = models.CharField(max_length=15, null=False)
    s_apellido = models.CharField(max_length=15, null=True, blank=True)

class Cuenta(models.Model):
    id_cuenta = models.AutoField(primary_key=True)
    empleado = models.ForeignKey(Empleado, on_delete=models.CASCADE)
    usuario = models.CharField(max_length=50, null=False)
    contrasena = models.CharField(max_length=128, null=False)
    correo = models.EmailField(max_length=50, null=False)
    tipo_cuenta = models.CharField(max_length=50, null=False)
    estado = models.BooleanField(default=True)


# Modelos de Representante y Municipalidad
class Representante(models.Model):
    id_representante = models.AutoField(primary_key=True)
    p_nombre = models.CharField(max_length=15, null=False)
    s_nombre = models.CharField(max_length=15, null=True, blank=True)
    p_apellido = models.CharField(max_length=15, null=False)
    s_apellido = models.CharField(max_length=15, null=True, blank=True)
    email = models.EmailField(max_length=50, null=False)  
    telefono = models.CharField(max_length=15, null=False)  

class Municipalidad(models.Model):
    id_municipalidad = models.AutoField(primary_key=True)
    representante = models.ForeignKey(Representante, on_delete=models.CASCADE)
    comuna = models.CharField(max_length=20, null=False)


# Modelo de Cruces e Inventario
class Inventario(models.Model):
    id_inventario = models.AutoField(primary_key=True)
    controlador = models.IntegerField(null=False)
    sensor = models.IntegerField(null=False)
    botoneras = models.IntegerField(null=False)
    poste1 = models.IntegerField(null=False)
    poste2 = models.IntegerField(null=False)
    poste3 = models.IntegerField(null=False)
    poste4 = models.IntegerField(null=False)

class Cruce(models.Model):
    id_cruce = models.AutoField(primary_key=True)
    municipalidad = models.ForeignKey(Municipalidad, on_delete=models.CASCADE)
    inventario = models.ForeignKey(Inventario, on_delete=models.CASCADE)
    calle1 = models.CharField(max_length=50, null=False)
    calle2 = models.CharField(max_length=50, null=False)


#### SISTEMA SOLICITUDES ####
class EstadoSolicitud(models.Model):
    id_e_solicitud = models.AutoField(primary_key=True)
    clasificacion = models.CharField(max_length=50, null=False)
    descripcion = models.CharField(max_length=200, null=False)

class Solicitud(models.Model):
    id_solicitud = models.AutoField(primary_key=True)
    estado = models.ForeignKey(EstadoSolicitud, on_delete=models.CASCADE)
    cruce = models.ForeignKey(Cruce, on_delete=models.CASCADE)
    fecha = models.DateField(null=False, default=get_current_date)
    hora = models.TimeField(null=False, default=get_current_time)
    descripcion = models.CharField(max_length=500, null=True, blank=True)

#### SISTEMA REPORTES ####
class Reporte(models.Model):
    id_reporte = models.AutoField(primary_key=True)
    cruce = models.ForeignKey(Cruce, on_delete=models.CASCADE)
    cuenta = models.ForeignKey(Cuenta, on_delete=models.CASCADE)
    hora = models.TimeField(null=False, default=get_current_time)
    fecha = models.DateField(null=False, default=get_current_date)
    r_controlador = models.CharField(max_length=50, null=True, blank=True)
    r_sensor = models.CharField(max_length=50, null=True, blank=True)
    r_botonera = models.CharField(max_length=50, null=True, blank=True)
    r_poste1 = models.CharField(max_length=50, null=True, blank=True)
    r_poste2 = models.CharField(max_length=50, null=True, blank=True)
    r_poste3 = models.CharField(max_length=50, null=True, blank=True)
    r_poste4 = models.CharField(max_length=50, null=True, blank=True)
    observacion = models.CharField(max_length=500, null=True, blank=True)

#### SISTEMA INFORMES ####
class Informe(models.Model):
    id_informe = models.AutoField(primary_key=True)
    mensaje = models.CharField(max_length=500, null=False)
    reporte = models.ForeignKey(Reporte, on_delete=models.CASCADE)
