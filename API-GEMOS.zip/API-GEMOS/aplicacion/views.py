from .models import *
from .serializers import *
from rest_framework import viewsets, permissions, status
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.shortcuts import get_object_or_404
from django.contrib.auth.models import *
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated



#### USUARIO #### 
class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = UserSerializer

class EmpleadoViewSet(viewsets.ModelViewSet):
    queryset = Empleado.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = EmpleadoSerializer

class CuentaViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = CuentaSerializer

#### REPRESENTANTE Y MUNICIPALIDAD #### 
class RepresentanteViewSet(viewsets.ModelViewSet):
    queryset = Representante.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = RepresentanteSerializer

class MunicipalidadViewSet(viewsets.ModelViewSet):
    queryset = Municipalidad.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = MunicipalidadSerializer


#### CRUCES E INVENTARIOS #### 
class InventarioViewSet(viewsets.ModelViewSet):
    queryset = Inventario.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = InventarioSerializer

class CruceViewSet(viewsets.ModelViewSet):
    queryset = Cruce.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = CruceSerializer


#### SISTEMA SOLICITUDES ####
class EstadoSolicitudViewSet(viewsets.ModelViewSet):
    queryset = EstadoSolicitud.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = EstadoSolicitudSerializer

class SolicitudViewSet(viewsets.ModelViewSet):
    queryset = Solicitud.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = SolicitudSerializer


#### SISTEMA REPORTES ####
class ReporteViewSet(viewsets.ModelViewSet):
    queryset = Reporte.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = ReporteSerializer


#### SISTEMA INFORMES ####
class InformeViewSet(viewsets.ModelViewSet):
    queryset = Informe.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = InformeSerializer