from django.shortcuts import render, redirect, get_object_or_404
from .models import *
from django.contrib import messages
from django.http import HttpResponse
from django.views.generic import View
from .utils import render_to_pdf 
from django.views import View
from django.template.loader import get_template
from xhtml2pdf import pisa
import io
from io import BytesIO  
from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages
from django.views import View
from .models import Informe
from io import BytesIO
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.contrib.auth.hashers import check_password
from django.contrib import messages
from .utils import get_current_date, get_current_time 


############## LOGIN ########################################################
#############################################################################
def login(request):
    return render(request, "login.html")

def logear(request):
    if request.method == "POST":
        correo = request.POST.get('correo')
        contrasena = request.POST.get('contrasena')
        try:
            cuenta = Cuenta.objects.get(correo=correo)
            if cuenta.contrasena == contrasena:
                if cuenta.estado:
                    # Si el login es exitoso, guarda los datos en sesión o similar
                    request.session['id_cuenta'] = cuenta.id_cuenta
                    request.session['usuario'] = cuenta.usuario
                    request.session['tipo_cuenta'] = cuenta.tipo_cuenta
                    # Redirige a la página deseada
                    return redirect('index_d')
                else:
                    messages.error(request, 'La cuenta está suspendida.')
                    return render(request, 'login.html', {'error_message': 'La cuenta está suspendida.'})
            else:
                messages.error(request, 'Contraseña incorrecta.')
                return render(request, 'login.html', {'error_message': 'Contraseña incorrecta.'})
        except Cuenta.DoesNotExist:
            messages.error(request, 'Correo electrónico incorrecto.')
            return render(request, 'login.html', {'error_message': 'Correo electrónico incorrecto.'})
    
    return render(request, 'login.html')

############## DIGITADOR  ########################################################
##################################################################################
############## INDEX
def index_d(request):
    # Obtener los datos de sesión guardados
    id_cuenta = request.session.get('id_cuenta')
    usuario = request.session.get('usuario')
    tipo_cuenta = request.session.get('tipo_cuenta')
    
    # Puedes pasar estos datos a la plantilla 'index.html'
    context = {
        'id_cuenta': id_cuenta,
        'usuario': usuario,
        'tipo_cuenta': tipo_cuenta,
    }
    
    return render(request, 'digitador/index.html', context)

def navindex_d(request):
    return index_d(request)  

############## SOLICITUDES
def solicitudes_d(request):
    id_cuenta = request.session.get('id_cuenta')
    usuario = request.session.get('usuario')
    tipo_cuenta = request.session.get('tipo_cuenta')
    solicitudes = Solicitud.objects.all()
    context = {
        'id_cuenta': id_cuenta,
        'usuario': usuario,
        'tipo_cuenta': tipo_cuenta,
        'solicitudes': solicitudes,
    }
    return render(request, 'digitador/solicitudes.html', context)

def navsolicitudes_d(request):
    return solicitudes_d(request)     

def solicitar_d(request):
    id_cuenta = request.session.get('id_cuenta')
    usuario = request.session.get('usuario')
    tipo_cuenta = request.session.get('tipo_cuenta')
    solicitudes = Solicitud.objects.all()
    cruces = Cruce.objects.all()
    # Puedes pasar estos datos a la plantilla 'index.html'
    context = {
        'id_cuenta': id_cuenta,
        'usuario': usuario,
        'tipo_cuenta': tipo_cuenta,
        'solicitudes': solicitudes,
        'cruces': cruces,
    }
    return render(request, 'digitador/solicitar.html', context)

def navsolicitar_d(request):
    return solicitar_d(request)    

def crearsolicitud(request):
    if request.method == 'POST':
        cruce_id = request.POST.get('cruce')
        descripcion = request.POST.get('descripcion')
        estado = 1 
        try:
            nueva_solicitud = Solicitud.objects.create(
                estado_id=estado,
                cruce_id=cruce_id,
                descripcion=descripcion
            )
            messages.success(request, 'Solicitud creada exitosamente.')  # Mensaje de éxito
            return redirect('navsolicitudes_d')  # Redirigir a la página de solicitudes después de éxito
            
        except Exception as e:
            messages.error(request, f'Ocurrió un error al crear la solicitud: {str(e)}')  # Mensaje de error
            return redirect('navsolicitar_d')  # Redirigir a alguna página o a la misma página de creación de solicitud
    return render(request, 'solicitar.html')

############## REPORTES
def reportes_d(request):
    id_cuenta = request.session.get('id_cuenta')
    usuario = request.session.get('usuario')
    tipo_cuenta = request.session.get('tipo_cuenta')
    reportes = Reporte.objects.all()
    context = {
        'id_cuenta': id_cuenta,
        'usuario': usuario,
        'tipo_cuenta': tipo_cuenta,
        'reportes': reportes,
    }
    return render(request, 'digitador/reportes.html', context)

def navreportes_d(request):
    return reportes_d(request)  

############## INFORMES
def informes_d(request):
    id_cuenta = request.session.get('id_cuenta')
    usuario = request.session.get('usuario')
    tipo_cuenta = request.session.get('tipo_cuenta')
    informes = Informe.objects.all()
    context = {
        'id_cuenta': id_cuenta,
        'usuario': usuario,
        'tipo_cuenta': tipo_cuenta,
        'informes': informes,
    }
    return render(request, 'digitador/informes.html', context)

def navinformes_d(request):
    return informes_d(request)


############## ADMINISTRADOR  ########################################################
######################################################################################
############## USUARIO
############## INDEX
############## SOLICITUDES
############## REPORTES
############## INFORMES



############## TECNICO  ########################################################
################################################################################
############## USUARIO
############## INDEX
############## SOLICITUDES
############## REPORTES
############## INFORMES



#### DECLARO PAGINAS INFORMES ####
def informesd(request):
    if 'usuario_id' in request.session:
        usuario_id = request.session.get('usuario_id')
        usuario = request.session.get('usuario')
        correo = request.session.get('correo')
        tipo_cuenta = request.session.get('tipo_cuenta')
        informes = Informe.objects.all()
        reportes = Reporte.objects.all()
        cuentas = Cuenta.objects.all()
        cruces = Cruce.objects.all()
        municipalidades = Municipalidad.objects.all()
        context = {
            'usuario_id': usuario_id,
            'usuario': usuario,
            'correo': correo,
            'tipo_cuenta': tipo_cuenta,
            'informes': informes,
            'reportes': reportes,
            'cuentas': cuentas,
            'cruces': cruces,
            'municipalidades': municipalidades,

        }
        return render(request, 'digitador/informes.html', context)
    else:
        return redirect('login')

def navinford(request):
    return informesd(request)
 

def informes(request):
    if 'usuario_id' in request.session:
        usuario_id = request.session.get('usuario_id')
        usuario = request.session.get('usuario')
        correo = request.session.get('correo')
        tipo_cuenta = request.session.get('tipo_cuenta')
        informes = Informe.objects.all()

        context = {
            'usuario_id': usuario_id,
            'usuario': usuario,
            'correo': correo,
            'tipo_cuenta': tipo_cuenta,
            'informes': informes,
        }
        return render(request, '1informes.html', context)
    else:
        return redirect('login')

def ver_informe(request, id_informe):
    try:
        informe = get_object_or_404(Informe, id_informe=id_informe)
        reporte = informe.reporte  # Obtener el reporte asociado al informe
        cruce = reporte.cruce
        municipalidad = cruce.municipalidad
        representante = municipalidad.representante

        context = {
            'id_informe': id_informe,
            'mensaje_informe': informe.mensaje,
            'id_reporte': reporte.id_reporte,
            'r_controlador': reporte.r_controlador,
            'r_sensor': reporte.r_sensor,
            'r_botonera': reporte.r_botonera,
            'r_poste1': reporte.r_poste1,
            'r_poste2': reporte.r_poste2,
            'r_poste3': reporte.r_poste3,
            'r_poste4': reporte.r_poste4,
            'observacion': reporte.observacion,
            'id_cruce': cruce.id_cruce,
            'calle1': cruce.calle1,
            'calle2': cruce.calle2,
            'id_municipalidad': municipalidad.id_municipalidad,
            'comuna': municipalidad.comuna,
            'id_representante': representante.id_representante,
            'rep_nombre_completo': f"{representante.p_nombre} {representante.s_nombre} {representante.p_apellido} {representante.s_apellido}",
            'rep_email': representante.email,
            'rep_telefono': representante.telefono,
        }

        return render(request, '1verinforme.html', context)
    
    except Informe.DoesNotExist:
        messages.error(request, 'El ID del informe no existe')
        return redirect('informes')


class GeneratePdf(View):
    def get(self, request, *args, **kwargs):
        id_informe = request.GET.get('id_informe')
        try:
            informe = Informe.objects.get(id_informe=id_informe)
            reporte = informe.reporte
            cruce = reporte.cruce
            municipalidad = cruce.municipalidad 
            cuenta = reporte.cuenta
            
            data = {
                "id_informe": informe.id_informe,
                "mensaje_informe": informe.mensaje,
                "id_reporte": reporte.id_reporte,
                "cuenta": {
                    "id_cuenta": cuenta.id_cuenta,
                    "empleado": {
                        "id_empleado": cuenta.empleado.id_empleado,
                        "rut": cuenta.empleado.rut,
                        "dv": cuenta.empleado.dv,
                        "p_nombre": cuenta.empleado.p_nombre,
                        "s_nombre": cuenta.empleado.s_nombre,
                        "p_apellido": cuenta.empleado.p_apellido,
                        "s_apellido": cuenta.empleado.s_apellido
                    },
                    "usuario": cuenta.usuario,
                    "correo": cuenta.correo,
                    "tipo_cuenta": cuenta.tipo_cuenta,
                    "estado": cuenta.estado
                },
                "hora": reporte.hora,
                "fecha": reporte.fecha,
                "r_controlador": reporte.r_controlador,
                "r_sensor": reporte.r_sensor,
                "r_botonera": reporte.r_botonera,
                "r_poste1": reporte.r_poste1,
                "r_poste2": reporte.r_poste2,
                "r_poste3": reporte.r_poste3,
                "r_poste4": reporte.r_poste4,
                "observacion": reporte.observacion,
                "id_cruce": cruce.id_cruce,
                "calle1": cruce.calle1,
                "calle2": cruce.calle2,
                "municipalidad_id": municipalidad.id_municipalidad,
                "municipalidad_comuna": municipalidad.comuna,
                "representante_p_nombre": municipalidad.representante.p_nombre,
                "representante_s_nombre": municipalidad.representante.s_nombre,
                "representante_p_apellido": municipalidad.representante.p_apellido,
                "representante_s_apellido": municipalidad.representante.s_apellido,
                "representante_email": municipalidad.representante.email,
                "representante_telefono": municipalidad.representante.telefono
            }
            
            pdf = render_to_pdf('informepdf.html', data)
            if pdf:
                response = HttpResponse(pdf, content_type='application/pdf')
                filename = f"Report_for_{id_informe}.pdf"
                content = f"inline; filename={filename}"
                response['Content-Disposition'] = content
                return response
            return HttpResponse("Page Not Found")
        except Informe.DoesNotExist:
            messages.error(request, 'El ID del informe no existe')
            return redirect('informes')


def render_to_pdf(template_src, context_dict={}):
    template = get_template(template_src)
    html = template.render(context_dict)
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("UTF-8")), result)
    if not pdf.err:
        return result.getvalue()
    return None