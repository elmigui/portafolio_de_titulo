from django.urls import path
from . import views
from .views import *
from .views import GeneratePdf

urlpatterns = [
    ############## LOGIN ########################################################
    #############################################################################
    path('', views.login),
    path('logear/', logear, name='logear'),                 
    

    ############## DIGITADOR ####################################################
    #############################################################################
    ############## INDEX
    path('index_d/', views.index_d, name='index_d'),
    path('navindex_d/', views.navindex_d, name='navindex_d'),

    ########### SOLICITUDES ###########
    path('solicitudes_d/', views.solicitudes_d, name='solicitudes_d'),
    path('navsolicitudes_d/', views.navsolicitudes_d, name='navsolicitudes_d'),
    path('solicitar_d/', views.solicitar_d, name='solicitar_d'),
    path('navsolicitar_d/', views.navsolicitar_d, name='navsolicitar_d'),
    path('crearsolicitud/', views.crearsolicitud, name='crearsolicitud'),

    ########### REPORTES ###########
    path('reportes_d/', views.reportes_d, name='reportes_d'),
    path('navreportes_d/', views.navreportes_d, name='navreportes_d'),

    ########### INFORMES ###########
    path('informes_d/', views.informes_d, name='informes_d'),
    path('navinformes_d/', views.navinformes_d, name='navinformes_d'),


    ########### INFORMES ###########

   

    path('informes/', views.informes, name='informes'),

    ########### NAVBAR ###########
    path('verinformes/', views.ver_informe, name='verinformes'),
    path('ver_informe/', views.ver_informe, name='ver_informe'),
    path('pdf/', GeneratePdf.as_view(),name='pdf'),



    path('navinford/', views.navinford, name='navinford'),

    path('pdf/', GeneratePdf.as_view(),name='pdf'), 
]
